<?php
// public/api/historique.php
// Désactiver l'affichage des erreurs pour éviter qu'elles ne polluent le JSON
error_reporting(0);
ini_set('display_errors', 0);

// Démarrer la bufferisation pour capturer toute sortie indésirable
ob_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');

try {
    require_once '../../config/database.php';

    // Vérifier que la connexion est établie
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not established');
    }

    // Récupérer les paramètres
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? min(100, max(10, (int)$_GET['limit'])) : 20;
    $station = isset($_GET['station']) ? trim($_GET['station']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $offset = ($page - 1) * $limit;

    // Construction de la requête avec filtres
    $whereConditions = [];
    $params = [];

    if (!empty($station)) {
        $whereConditions[] = "s.nom_station = ?";
        $params[] = $station;
    }

    if (!empty($search)) {
        $whereConditions[] = "(s.nom_station LIKE ? OR s.emplacement LIKE ? OR m.etat LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    $whereClause = empty($whereConditions) ? '' : 'WHERE ' . implode(' AND ', $whereConditions);

    // Requête pour le nombre total d'enregistrements
    $countSql = "
        SELECT COUNT(*) as total
        FROM mesures m
        JOIN stations s ON s.id = m.station_id
        $whereClause
    ";
    $stmt = $pdo->prepare($countSql);
    $stmt->execute($params);
    $totalCount = $stmt->fetch()['total'];

    // Requête pour les données paginées
    $sql = "
        SELECT
            m.id,
            s.nom_station,
            s.emplacement,
            m.temperature,
            m.humidite,
            m.distance,
            m.presence,
            m.etat,
            m.date_mesure
        FROM mesures m
        JOIN stations s ON s.id = m.station_id
        $whereClause
        ORDER BY m.date_mesure DESC
        LIMIT ? OFFSET ?
    ";

    $stmt = $pdo->prepare($sql);

    // IMPORTANT : on binde chaque paramètre WHERE en STRING,
    // puis LIMIT/OFFSET explicitement en INT.
    // (execute($params) seul enverrait LIMIT/OFFSET comme chaînes
    // entre guillemets, ce que MySQL peut refuser -> erreur SQL silencieuse)
    $paramIndex = 1;
    foreach ($params as $value) {
        $stmt->bindValue($paramIndex++, $value, PDO::PARAM_STR);
    }
    $stmt->bindValue($paramIndex++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($paramIndex++, $offset, PDO::PARAM_INT);
    $stmt->execute();

    $data = $stmt->fetchAll();

    // Convertir les champs numériques/booléens (PDO les renvoie en string)
    foreach ($data as &$row) {
        $row['temperature'] = (float)$row['temperature'];
        $row['humidite'] = (float)$row['humidite'];
        $row['distance'] = (float)$row['distance'];
        $row['presence'] = (int)$row['presence'];
        $row['id'] = (int)$row['id'];
    }
    unset($row);

    // Récupérer la liste des stations pour le filtre
    $stationsStmt = $pdo->query("SELECT nom_station FROM stations ORDER BY nom_station");
    $stationsList = $stationsStmt->fetchAll(PDO::FETCH_COLUMN);

    // S'assurer que $stationsList est toujours un tableau
    if ($stationsList === false) {
        $stationsList = [];
    }

    // Vider le buffer avant d'envoyer le JSON
    ob_clean();

    $response = [
        'data' => $data,
        'pagination' => [
            'current_page' => $page,
            'per_page' => $limit,
            'total' => (int)$totalCount,
            'total_pages' => $totalCount > 0 ? (int)ceil($totalCount / $limit) : 1
        ],
        'filters' => [
            'stations' => $stationsList,
            'current_station' => $station,
            'search' => $search
        ]
    ];

    echo json_encode($response);
    ob_end_flush();

} catch (PDOException $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode([
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
    ob_end_flush();
} catch (Exception $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode([
        'error' => 'Server error',
        'message' => $e->getMessage()
    ]);
    ob_end_flush();
} catch (Throwable $e) {
    ob_clean();
    http_response_code(500);
    echo json_encode([
        'error' => 'Fatal error',
        'message' => $e->getMessage()
    ]);
    ob_end_flush();
}