#include "DHT.h"

//====================================================
// IDENTIFIANT DE LA STATION
//====================================================

const String STATION_ID = "SALLE_01";

//====================================================
// DHT11
//====================================================

#define DHTPIN 2

DHT dht;

//====================================================
// HC-SR04
//====================================================

const int trigPin = 4;
const int echoPin = 6;

long duration = 0;
int distance = 0;

//====================================================
// LEDs
//====================================================

// Verte
const int LED_VERTE = 11;

// Orange
const int LED_ORANGE = 12;

// Rouge
const int LED_ROUGE = 13;

//====================================================
// Variables
//====================================================

String commande = "";

unsigned long dernierEnvoi = 0;

//====================================================
// SETUP
//====================================================

void setup()
{
    pinMode(LED_VERTE, OUTPUT);
    pinMode(LED_ORANGE, OUTPUT);
    pinMode(LED_ROUGE, OUTPUT);

    digitalWrite(LED_VERTE, LOW);
    digitalWrite(LED_ORANGE, LOW);
    digitalWrite(LED_ROUGE, LOW);

    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);

    Serial.begin(9600);

    dht.setup(DHTPIN);

    delay(2000);

    Serial.println("================================");
    Serial.println("Station SALLE_01");
    Serial.println("================================");
}

//====================================================
// LOOP
//====================================================

void loop()
{
    recevoirCommande();

    if (millis() - dernierEnvoi >= dht.getMinimumSamplingPeriod())
    {
        dernierEnvoi = millis();

        envoyerMesures();
    }
}

//====================================================
// ENVOI DES MESURES
//====================================================

void envoyerMesures()
{
    float temperature = dht.getTemperature();
    float humidite = dht.getHumidity();

    mesurerDistance();

    if (dht.getStatus() != DHT::ERROR_NONE)
    {
        Serial.println("ERREUR_DHT");
        return;
    }

    // Format :
    // SALLE_01;29.5;65.0;23

    Serial.print(STATION_ID);
    Serial.print(";");

    Serial.print(temperature, 1);
    Serial.print(";");

    Serial.print(humidite, 1);
    Serial.print(";");

    Serial.println(distance);
}

//====================================================
// MESURE HC-SR04
//====================================================

void mesurerDistance()
{
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);

    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);

    digitalWrite(trigPin, LOW);

    duration = pulseIn(echoPin, HIGH, 30000);

    if (duration == 0)
    {
        distance = 999;
    }
    else
    {
        distance = duration * 0.034 / 2;
    }
}

//====================================================
// RECEPTION DES COMMANDES NODE-RED
//====================================================

void recevoirCommande()
{
    while (Serial.available())
    {
        char c = Serial.read();

        if (c == '\n' || c == '\r')
        {
            if (commande.length() > 0)
            {
                commande.trim();

                appliquerEtat(commande);

                commande = "";
            }
        }
        else
        {
            commande += c;
        }
    }
}

//====================================================
// APPLICATION DES ETATS
//====================================================

void appliquerEtat(String etat)
{
    eteindreToutes();

    if (etat == "AUTORISE")
    {
        digitalWrite(LED_VERTE, HIGH);

        Serial.println("Etat : AUTORISE");
    }

    else if (etat == "REFUSE")
    {
        digitalWrite(LED_ROUGE, HIGH);

        Serial.println("Etat : ");
    }

    else if (etat == "PREALERTE")
    {
        digitalWrite(LED_ORANGE, HIGH);

        Serial.println("Etat : PREALERTE");
    }

    else if (etat == "VEILLE")
    {
        Serial.println("Etat : VEILLE");
    }
}

//====================================================
// ETEINDRE LES LEDs
//====================================================

void eteindreToutes()
{
    digitalWrite(LED_VERTE, LOW);
    digitalWrite(LED_ORANGE, LOW);
    digitalWrite(LED_ROUGE, LOW);
}