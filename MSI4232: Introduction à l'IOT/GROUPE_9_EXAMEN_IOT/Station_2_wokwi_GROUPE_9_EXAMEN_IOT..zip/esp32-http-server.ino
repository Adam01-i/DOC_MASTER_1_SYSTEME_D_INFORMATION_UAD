#include <WiFi.h>
#include "DHT.h"

// --- CONFIGURATION ---
const char* stationID = "SALLE_02"; // CHANGER ICI POUR SALLE_01 sur l'autre ESP32
const char* ssid = "VOTRE_WIFI";
const char* password = "VOTRE_PASSWORD";

// --- PINS ESP32 ---
#define DHTPIN 4
#define DHTTYPE DHT11
#define TRIG_PIN 5
#define ECHO_PIN 18
#define LED_VERTE 21
#define LED_ROUGE 22
#define LED_ORANGE 23

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_VERTE, OUTPUT);
  pinMode(LED_ROUGE, OUTPUT);
  pinMode(LED_ORANGE, OUTPUT);
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("Connecté au Wi-Fi !");
}

void loop() {
  // Lecture capteurs
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  float distance = pulseIn(ECHO_PIN, HIGH) * 0.034 / 2;

  // Envoi ici (MQTT ou HTTP)
  Serial.printf("Station: %s | T: %.1f | H: %.1f | D: %.1f\n", stationID, t, h, distance);
  
  delay(5000); // Envoi toutes les 5 secondes
}