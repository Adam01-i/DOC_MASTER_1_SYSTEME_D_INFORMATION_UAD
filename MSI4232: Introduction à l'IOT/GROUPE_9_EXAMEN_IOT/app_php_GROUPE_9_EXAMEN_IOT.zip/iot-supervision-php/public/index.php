<!-- iot-supervision-php/public/index.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IoT Supervision - Système Multi-Salles</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    </style>
</head>
<body>
    <div id="app">
        <!-- Barre de navigation -->
        <nav class="navbar">
            <div class="nav-brand">
                <span class="logo-icon">⚡</span>
                <span class="brand-text">IoT Supervisor</span>
            </div>
            <div class="nav-links">
                <button class="nav-link active" data-page="dashboard">📊 Dashboard</button>
                <button class="nav-link" data-page="historique">📜 Historique</button>
                <button class="nav-link" data-page="statistiques">📈 Statistiques</button>
            </div>
            <div class="nav-status">
                <span class="status-dot"></span>
                <span class="status-text">Live</span>
            </div>
        </nav>

        <!-- Contenu principal -->
        <main id="main-content">
            <!-- Le contenu est chargé dynamiquement via JavaScript -->
        </main>
    </div>

    <script src="assets/js/app.js"></script>
</body>
</html>