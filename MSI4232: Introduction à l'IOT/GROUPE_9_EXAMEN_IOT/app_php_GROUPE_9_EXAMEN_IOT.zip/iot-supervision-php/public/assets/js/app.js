// public/assets/js/app.js

// Gestionnaire de page
class IoTApp {
  constructor() {
    this.currentPage = "dashboard";
    this.data = null;
    this.charts = {};
    this.init();
  }

  async init() {
    this.setupNavigation();
    await this.loadPage("dashboard");
    this.startAutoRefresh();
  }

  setupNavigation() {
    document.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", async (e) => {
        document
          .querySelectorAll(".nav-link")
          .forEach((l) => l.classList.remove("active"));
        e.target.classList.add("active");
        const page = e.target.dataset.page;
        await this.loadPage(page);
      });
    });
  }

  async loadPage(page) {
    this.currentPage = page;
    const main = document.getElementById("main-content");

    switch (page) {
      case "dashboard":
        main.innerHTML = this.renderDashboardLoading();
        await this.loadDashboard();
        break;
      case "historique":
        main.innerHTML = this.renderHistoriqueLoading();
        await this.loadHistorique(1, "", "", 20);
        break;
      case "statistiques":
        main.innerHTML = this.renderStatistiquesLoading();
        await this.loadStatistiques();
        break;
    }
  }

  // ============================================
  // Helpers communs
  // ============================================

  // PDO renvoie souvent les valeurs sous forme de chaînes ("0"/"1"),
  // et en JS "0" est truthy -> on force une vraie comparaison numérique.
  isPresent(value) {
    return Number(value) === 1;
  }

  // Gestion à 3 états (la base peut renvoyer AUTORISE / PREALERTE / ALERTE)
  getEtatClass(etat) {
    switch (etat) {
      case "ALERTE":
        return "status-alerte";
      case "PREALERTE":
        return "status-prealerte";
      case "AUTORISE":
      default:
        return "status-autorise";
    }
  }

  async loadDashboard() {
    try {
      const response = await fetch("/api/dashboard.php");
      const text = await response.text();
      const data = JSON.parse(text);
      this.data = data;
      const main = document.getElementById("main-content");
      main.innerHTML = this.renderDashboard(data);
      this.initCharts(data);
    } catch (error) {
      console.error("Erreur de chargement du dashboard:", error);
    }
  }

  renderDashboard(data) {
    const stats = data.statistiques;
    const stations = data.stations;

    return `
      <div class="dashboard-grid">
        <div class="glass-card stat-card">
          <div class="icon">🏢</div>
          <div class="value">${stats.total_salles}</div>
          <div class="label">Total Salles</div>
        </div>
        <div class="glass-card stat-card">
          <div class="icon">✅</div>
          <div class="value">${stats.salles_actives}</div>
          <div class="label">Salles Actives</div>
        </div>
        <div class="glass-card stat-card">
          <div class="icon">🌡️</div>
          <div class="value">${Math.round(stats.temperature_moyenne)}°C</div>
          <div class="label">Température Moyenne</div>
        </div>
        <div class="glass-card stat-card">
          <div class="icon">⚠️</div>
          <div class="value">${stats.alertes}</div>
          <div class="label">Alertes Actives</div>
        </div>
      </div>
      <div class="stations-grid">
        ${stations
          .map(
            (station) => `
          <div class="glass-card station-card">
            <div class="station-header">
              <div>
                <div class="station-name">${station.nom_station}</div>
                <div class="station-location">${station.emplacement}</div>
              </div>
              <span class="status-badge ${this.getEtatClass(station.etat)}">
                ${station.etat}
              </span>
            </div>
            <div class="station-data">
              <div class="data-item">
                <span class="label">Température</span>
                <span class="value">${station.temperature}°C</span>
              </div>
              <div class="data-item">
                <span class="label">Humidité</span>
                <span class="value">${station.humidite}%</span>
              </div>
              <div class="data-item">
                <span class="label">Distance</span>
                <span class="value">${station.distance}cm</span>
              </div>
              <div class="data-item">
                <span class="label">Présence</span>
                <span class="value">${this.isPresent(station.presence) ? "👤 Oui" : "❌ Non"}</span>
              </div>
            </div>
            <div style="margin-top: 12px; font-size: 12px; color: #8899b0;">
              Dernière mise à jour: ${station.date_mesure ? new Date(station.date_mesure).toLocaleTimeString() : "N/A"}
            </div>
          </div>
        `
          )
          .join("")}
      </div>
    `;
  }

  // Pages de chargement
  renderDashboardLoading() {
    return `<div style="text-align: center; padding: 60px; color: #8899b0;">Chargement du dashboard...</div>`;
  }

  renderHistoriqueLoading() {
    return `<div style="text-align: center; padding: 60px; color: #8899b0;">Chargement de l'historique...</div>`;
  }

  renderStatistiquesLoading() {
    return `<div style="text-align: center; padding: 60px; color: #8899b0;">Chargement des statistiques...</div>`;
  }

  // ============================================
  // HISTORIQUE - Méthodes
  // ============================================

  async loadHistorique(page = 1, station = "", search = "", perPage = 20) {
    const main = document.getElementById("main-content");

    // Afficher le loader
    main.innerHTML = `
      <div style="text-align: center; padding: 60px; color: #8899b0;">
        <div style="display: inline-block; width: 40px; height: 40px; border: 3px solid rgba(0,212,255,0.1); border-top-color: #00d4ff; border-radius: 50%; animation: spin 1s linear infinite;"></div>
        <p style="margin-top: 16px;">Chargement de l'historique...</p>
      </div>
      <style>
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      </style>
    `;

    try {
      // Construire l'URL avec les paramètres
      let url = `/api/historique.php?page=${page}&limit=${perPage}`;
      if (station) url += `&station=${encodeURIComponent(station)}`;
      if (search) url += `&search=${encodeURIComponent(search)}`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();

      if (!result || !result.data) {
        throw new Error("Données invalides reçues");
      }

      const { data, pagination, filters } = result;

      main.innerHTML = this.renderHistorique(data, pagination, filters, page, station, search);

      this.attachHistoriqueEvents(pagination, filters, page, station, search);
    } catch (error) {
      console.error("Erreur de chargement de l'historique:", error);
      main.innerHTML = `
        <div style="text-align: center; padding: 60px; color: #ef4444;">
          <div style="font-size: 48px; margin-bottom: 16px;">⚠️</div>
          <p>Erreur lors du chargement de l'historique</p>
          <p style="font-size: 14px; margin-top: 8px; color: #8899b0;">${error.message}</p>
          <button onclick="location.reload()" style="margin-top: 12px; padding: 8px 20px; background: rgba(239,68,68,0.2); border: 1px solid rgba(239,68,68,0.3); border-radius: 8px; color: #ef4444; cursor: pointer;">Réessayer</button>
        </div>
      `;
    }
  }

  renderHistorique(data, pagination, filters, currentPage, currentStation, currentSearch) {
    const { total, per_page, current_page, total_pages } = pagination;

    const rows = data.length > 0
      ? data.map((row, index) => {
          const tempClass = row.temperature > 30 ? 'hot' : row.temperature < 15 ? 'cold' : '';
          const isPresent = this.isPresent(row.presence);
          const presenceClass = isPresent ? 'presence-present' : 'presence-absent';
          const presenceLabel = isPresent ? '👤 Présent' : '❌ Absent';
          const statusClass = this.getEtatClass(row.etat);

          return `
            <tr style="animation-delay: ${index * 0.03}s">
              <td>
                <div style="font-weight: 500;">${new Date(row.date_mesure).toLocaleDateString('fr-FR', {
                  day: '2-digit', month: 'short', year: 'numeric'
                })}</div>
                <div style="font-size: 12px; color: #8899b0;">${new Date(row.date_mesure).toLocaleTimeString('fr-FR', {
                  hour: '2-digit', minute: '2-digit', second: '2-digit'
                })}</div>
              </td>
              <td>
                <div class="station-name">${row.nom_station}</div>
                <span class="station-location">${row.emplacement}</span>
              </td>
              <td>
                <span class="temp-value ${tempClass}">${row.temperature}°C</span>
              </td>
              <td>
                <span class="humidity-value">${row.humidite}%</span>
              </td>
              <td>
                <span class="distance-value">${row.distance} cm</span>
              </td>
              <td>
                <span class="presence-badge ${presenceClass}">${presenceLabel}</span>
              </td>
              <td>
                <span class="status-badge ${statusClass}">${row.etat}</span>
              </td>
            </tr>
          `;
        }).join('')
      : `
        <tr>
          <td colspan="7" style="text-align: center; padding: 40px 20px; color: #8899b0;">
            <div style="font-size: 48px; margin-bottom: 12px;">📭</div>
            <p>Aucune mesure trouvée</p>
            <p style="font-size: 13px; margin-top: 8px;">Essayez de modifier vos filtres de recherche</p>
          </td>
        </tr>
      `;

    // Générer les options de pagination
    const pageOptions = [];
    const maxVisible = 5;
    let startPage = Math.max(1, current_page - Math.floor(maxVisible / 2));
    let endPage = Math.min(total_pages, startPage + maxVisible - 1);
    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(1, endPage - maxVisible + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pageOptions.push(`
        <button class="pagination-btn ${i === current_page ? 'active' : ''}" data-page="${i}">
          ${i}
        </button>
      `);
    }

    const stationOptions = filters.stations && filters.stations.length > 0
      ? filters.stations.map(s => `
          <option value="${s}" ${s === currentStation ? 'selected' : ''}>${s}</option>
        `).join('')
      : '';

    // Le sélecteur "par page" doit refléter le per_page réellement utilisé
    const perPageChoices = [10, 20, 50, 100];
    const perPageOptions = perPageChoices.map(n => `
      <option value="${n}" ${n === per_page ? 'selected' : ''}>${n} / page</option>
    `).join('');

    return `
      <div class="historique-container">
        <!-- En-tête -->
        <div class="historique-header">
          <h2 class="historique-title">📜 Historique des Mesures</h2>

          <div class="historique-controls">
            <!-- Recherche -->
            <div class="historique-search">
              <span class="search-icon">🔍</span>
              <input type="text" id="historiqueSearch" placeholder="Rechercher..." value="${currentSearch || ''}">
            </div>

            <!-- Filtre par station -->
            <select class="historique-select" id="historiqueStation">
              <option value="">Toutes les stations</option>
              ${stationOptions}
            </select>

            <!-- Bouton de rafraîchissement -->
            <button id="historiqueRefresh" style="background: rgba(0,212,255,0.1); border: 1px solid rgba(0,212,255,0.2); border-radius: 10px; color: #00d4ff; padding: 10px 16px; cursor: pointer; transition: all 0.3s ease;">
              🔄
            </button>
          </div>
        </div>

        <!-- Tableau -->
        <div class="historique-table-wrapper">
          <table class="historique-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Station</th>
                <th>Température</th>
                <th>Humidité</th>
                <th>Distance</th>
                <th>Présence</th>
                <th>État</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>

          <!-- Pagination -->
          ${total > 0 ? `
          <div class="pagination-container">
            <div class="pagination-info">
              Affichage de <strong>${(current_page - 1) * per_page + 1}</strong> à
              <strong>${Math.min(current_page * per_page, total)}</strong> sur
              <strong>${total}</strong> mesures
            </div>

            <div class="pagination-controls">
              <button class="pagination-btn" data-page="1" ${current_page <= 1 ? 'disabled' : ''}>
                <span class="arrow">⏮</span>
              </button>
              <button class="pagination-btn" data-page="${current_page - 1}" ${current_page <= 1 ? 'disabled' : ''}>
                <span class="arrow">◀</span>
              </button>

              ${pageOptions.join('')}

              <button class="pagination-btn" data-page="${current_page + 1}" ${current_page >= total_pages ? 'disabled' : ''}>
                <span class="arrow">▶</span>
              </button>
              <button class="pagination-btn" data-page="${total_pages}" ${current_page >= total_pages ? 'disabled' : ''}>
                <span class="arrow">⏭</span>
              </button>

              <select class="pagination-select" id="paginationPerPage">
                ${perPageOptions}
              </select>
            </div>
          </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  attachHistoriqueEvents(pagination, filters, currentPage, currentStation, currentSearch) {
    const getPerPage = () => {
      const sel = document.getElementById('paginationPerPage');
      return sel ? parseInt(sel.value) : pagination.per_page;
    };

    // Événements de pagination
    document.querySelectorAll('.pagination-btn[data-page]').forEach(btn => {
      btn.addEventListener('click', () => {
        const page = parseInt(btn.dataset.page);
        if (page > 0 && page <= pagination.total_pages) {
          const station = document.getElementById('historiqueStation').value;
          const search = document.getElementById('historiqueSearch').value;
          this.loadHistorique(page, station, search, getPerPage());
        }
      });
    });

    // Recherche avec debounce
    const searchInput = document.getElementById('historiqueSearch');
    if (searchInput) {
      let debounceTimer;
      searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          const station = document.getElementById('historiqueStation').value;
          const search = searchInput.value;
          this.loadHistorique(1, station, search, getPerPage());
        }, 500);
      });
    }

    // Filtre par station
    const stationSelect = document.getElementById('historiqueStation');
    if (stationSelect) {
      stationSelect.addEventListener('change', () => {
        const station = stationSelect.value;
        const search = document.getElementById('historiqueSearch').value;
        this.loadHistorique(1, station, search, getPerPage());
      });
    }

    // Bouton de rafraîchissement
    const refreshBtn = document.getElementById('historiqueRefresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        const station = document.getElementById('historiqueStation').value;
        const search = document.getElementById('historiqueSearch').value;
        this.loadHistorique(currentPage, station, search, getPerPage());
      });
    }

    // Changement du nombre d'éléments par page (repart à la page 1)
    const perPageSelect = document.getElementById('paginationPerPage');
    if (perPageSelect) {
      perPageSelect.addEventListener('change', () => {
        const station = document.getElementById('historiqueStation').value;
        const search = document.getElementById('historiqueSearch').value;
        this.loadHistorique(1, station, search, parseInt(perPageSelect.value));
      });
    }

    // Navigation au clavier (flèches)
    document.addEventListener('keydown', (e) => {
      if (this.currentPage === 'historique') {
        if (e.key === 'ArrowLeft' && pagination.current_page > 1) {
          const station = document.getElementById('historiqueStation').value;
          const search = document.getElementById('historiqueSearch').value;
          this.loadHistorique(pagination.current_page - 1, station, search, getPerPage());
        } else if (e.key === 'ArrowRight' && pagination.current_page < pagination.total_pages) {
          const station = document.getElementById('historiqueStation').value;
          const search = document.getElementById('historiqueSearch').value;
          this.loadHistorique(pagination.current_page + 1, station, search, getPerPage());
        }
      }
    });
  }

  // ============================================
  // STATISTIQUES - Méthodes
  // ============================================

  async loadStatistiques() {
    const main = document.getElementById("main-content");
    main.innerHTML = `
      <div style="padding: 24px; max-width: 1400px; margin: 0 auto;">
        <h2 style="margin-bottom: 24px;">📈 Statistiques Avancées</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div class="glass-card">
            <h3 style="margin-bottom: 16px; font-size: 16px;">Température par Salle</h3>
            <canvas id="chartTemp"></canvas>
          </div>
          <div class="glass-card">
            <h3 style="margin-bottom: 16px; font-size: 16px;">Distribution des États</h3>
            <canvas id="chartEtats"></canvas>
          </div>
        </div>
      </div>
    `;

    setTimeout(() => {
      this.initStatCharts();
    }, 100);
  }

  initStatCharts() {
    if (!this.data) return;

    const stations = this.data.stations || [];

    // Détruire les instances précédentes pour éviter les fuites/doublons
    if (this.charts.temp) this.charts.temp.destroy();
    if (this.charts.etats) this.charts.etats.destroy();

    // Graphique des températures
    const ctx1 = document.getElementById("chartTemp")?.getContext("2d");
    if (ctx1) {
      this.charts.temp = new Chart(ctx1, {
        type: "bar",
        data: {
          labels: stations.map((s) => s.nom_station),
          datasets: [
            {
              label: "Température (°C)",
              data: stations.map((s) => Number(s.temperature) || 0),
              backgroundColor: "rgba(0, 212, 255, 0.6)",
              borderColor: "#00d4ff",
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              labels: { color: "#e0e6ed" },
            },
          },
          scales: {
            y: {
              ticks: { color: "#8899b0" },
              grid: { color: "rgba(255,255,255,0.05)" },
            },
            x: {
              ticks: { color: "#8899b0" },
              grid: { color: "rgba(255,255,255,0.05)" },
            },
          },
        },
      });
    }

    // Graphique des états (3 états : AUTORISE / PREALERTE / ALERTE)
    const ctx2 = document.getElementById("chartEtats")?.getContext("2d");
    if (ctx2) {
      const autorises = stations.filter((s) => s.etat === "AUTORISE").length;
      const prealertes = stations.filter((s) => s.etat === "PREALERTE").length;
      const alertes = stations.filter((s) => s.etat === "ALERTE").length;

      this.charts.etats = new Chart(ctx2, {
        type: "doughnut",
        data: {
          labels: ["Autorisé", "Préalerte", "Alerte"],
          datasets: [
            {
              data: [autorises, prealertes, alertes],
              backgroundColor: ["#10b981", "#f59e0b", "#ef4444"],
              borderColor: ["#0a0e17", "#0a0e17", "#0a0e17"],
              borderWidth: 2,
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              labels: { color: "#e0e6ed" },
            },
          },
        },
      });
    }
  }

  startAutoRefresh() {
    setInterval(async () => {
      if (this.currentPage === "dashboard") {
        await this.loadDashboard();
      }
    }, 30000);
  }

  initCharts(data) {
    // Réservé à une future évolution (ex: graphique d'évolution temporelle)
  }
}

// Initialisation de l'application
document.addEventListener("DOMContentLoaded", () => {
  new IoTApp();
});