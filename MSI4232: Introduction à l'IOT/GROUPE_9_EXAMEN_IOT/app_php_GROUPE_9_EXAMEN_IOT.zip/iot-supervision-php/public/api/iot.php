<?php
// public/api/iot.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    // Validation des données
    $required = ['station', 'temperature', 'humidite', 'distance'];
    foreach ($required as $field) {
        if (!isset($input[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing field: $field"]);
            exit;
        }
    }

    try {
        // Récupération de la station
        $stmt = $pdo->prepare("SELECT id FROM stations WHERE nom_station = ?");
        $stmt->execute([$input['station']]);
        $station = $stmt->fetch();

        if (!$station) {
            http_response_code(404);
            echo json_encode(['error' => 'Station not found']);
            exit;
        }

        // Détermination de l'état
        $presence = $input['distance'] < 30;

        if ($input['temperature'] > 35 || $input['humidite'] > 80) {

            $etat = 'ALERTE';

        } elseif ($presence) {

            $etat = 'AUTORISE';

        } else {

            $etat = 'PREALERTE';

        }

        // Insertion de la mesure
        $stmt = $pdo->prepare("
            INSERT INTO mesures (station_id, temperature, humidite, distance, presence, etat)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $station['id'],
            $input['temperature'],
            $input['humidite'],
            $input['distance'],
            $presence ? 1 : 0,
            $etat
        ]);

        // Mise à jour de la dernière communication
        $stmt = $pdo->prepare("UPDATE stations SET derniere_communication = NOW() WHERE id = ?");
        $stmt->execute([$station['id']]);

        // Log d'événement si alerte
        if ($etat === 'ALERTE') {
            $stmt = $pdo->prepare("
                INSERT INTO evenements (station_id, type_evenement, description)
                VALUES (?, 'ALERTE', ?)
            ");
            $description = "Température: {$input['temperature']}°C, Humidité: {$input['humidite']}%";
            $stmt->execute([$station['id'], $description]);
        }

        echo json_encode([
            'success' => true,
            'message' => 'Data received successfully',
            'etat' => $etat,
            'presence' => $presence
        ]);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>