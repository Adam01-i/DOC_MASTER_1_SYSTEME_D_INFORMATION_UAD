<?php
// public/api/dashboard.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once '../../config/database.php';

function getDashboardStats($pdo) {
    // Statistiques globales
    $stmt = $pdo->query("SELECT * FROM vue_statistiques_globales");
    $stats = $stmt->fetch();

    // Dernières mesures de toutes les stations
    $stmt = $pdo->query("SELECT * FROM vue_dernieres_mesures ORDER BY nom_station");
    $stations = $stmt->fetchAll();

    // Événements récents
    $stmt = $pdo->query("
        SELECT e.*, s.nom_station 
        FROM evenements e 
        JOIN stations s ON e.station_id = s.id 
        ORDER BY e.date_evenement DESC 
        LIMIT 10
    ");
    $evenements = $stmt->fetchAll();


    return [
        'statistiques' => $stats,
        'stations' => $stations,
        'evenements' => $evenements
    ];

}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = getDashboardStats($pdo);
    echo json_encode($data);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>